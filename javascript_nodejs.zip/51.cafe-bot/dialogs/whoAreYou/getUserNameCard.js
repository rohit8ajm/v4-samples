// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const getUserNameCard = require('./resources/getNameCard.json');

module.exports.GetUserNameCard = getUserNameCard;
