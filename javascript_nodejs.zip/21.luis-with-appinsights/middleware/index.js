// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { MyAppInsightsMiddleware } = require('./myAppInsightsMiddleware');

exports.MyAppInsightsMiddleware = MyAppInsightsMiddleware;
